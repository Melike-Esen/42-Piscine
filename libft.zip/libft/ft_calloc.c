/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: meesen <meesen@student.42kocaeli.com.tr    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/28 17:37:56 by meesen            #+#    #+#             */
/*   Updated: 2025/06/12 12:16:40 by meesen           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdlib.h> 

void	*ft_calloc(size_t nmemb, size_t size)
{
	size_t			total;
	unsigned char	*str;
	size_t			i;

	total = nmemb * size;
	str = (unsigned char *)malloc(total);
	if (!str)
		return (NULL);
	i = 0;
	while (i < total)
	{
		str[i] = 0;
		i++;
	}
	return ((void *)str);
}
